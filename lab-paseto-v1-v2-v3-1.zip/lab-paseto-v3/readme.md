# lab-paseto-v3

V3 — CRUD completo, validaciones con express-validator, roles y Swagger (http://localhost:3000/api-docs).

## Ejecutar

```bash
npm install
npm run dev
```

Usuario de prueba: `admin@hospital.com` / `123456`.
