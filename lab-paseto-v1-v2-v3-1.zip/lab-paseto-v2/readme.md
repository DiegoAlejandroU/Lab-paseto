# lab-paseto-v2

V2 — Usuarios locales, roles, autorización y Swagger (http://localhost:3000/api-docs).

## Ejecutar

```bash
npm install
npm run dev
```

Usuario de prueba: `admin@hospital.com` / `123456`.
