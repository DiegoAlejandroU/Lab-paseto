# lab-paseto

V1 — PASETO básico: login, token v4.public y ruta protegida.

## Ejecutar

```bash
npm install
npm run dev
```

Usuario de prueba: `admin@hospital.com` / `123456`.
