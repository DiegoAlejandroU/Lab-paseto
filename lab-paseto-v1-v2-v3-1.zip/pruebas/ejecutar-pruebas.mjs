// Ejecuta las pruebas de las 3 versiones contra servidores reales
// Uso: node pruebas/ejecutar-pruebas.mjs   (desde la raíz del repo)
import { spawn } from "node:child_process";
import { writeFileSync } from "node:fs";

const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

const levantar = async (carpeta, puerto) => {
  const proc = spawn("node", ["src/app.js"], {
    cwd: carpeta,
    env: { ...process.env, PORT: String(puerto) },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let salida = "";
  proc.stdout.on("data", (d) => (salida += d));
  proc.stderr.on("data", (d) => (salida += d));
  for (let i = 0; i < 50; i++) {
    if (salida.includes("Servidor ejecutándose")) break;
    await esperar(100);
  }
  return { proc, salida: () => salida };
};

const pedir = async (base, metodo, ruta, { body, token } = {}) => {
  const headers = {};
  if (body !== undefined) headers["Content-Type"] = "application/json";
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const r = await fetch(base + ruta, {
    method: metodo,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  const texto = await r.text();
  let json = null;
  try { json = texto ? JSON.parse(texto) : null; } catch { json = texto; }
  return { status: r.status, body: json };
};

// Altera un carácter del payload del token (después de "v4.public.")
const manipular = (t) => {
  const i = 12;
  const c = t[i] === "X" ? "Y" : "X";
  return t.slice(0, i) + c + t.slice(i + 1);
};

const resultados = {};
const registrar = (v, n, nombre, metodo, ruta, esperado, r, extra = {}) => {
  (resultados[v] ??= []).push({
    n, nombre, metodo, ruta, esperado, obtenido: r.status,
    ok: r.status === esperado, respuesta: r.body, ...extra,
  });
};

const ADMIN = { email: "admin@hospital.com", password: "123456" };
const LAURA = { email: "laura@hospital.com", password: "123456" };
const CARLOS = { email: "carlos@hospital.com", password: "123456" };

// ================= V1 =================
{
  const s = await levantar("lab-paseto", 3101);
  const B = "http://localhost:3101";
  let r = await pedir(B, "POST", "/api/auth/login", { body: ADMIN });
  const token = r.body.token;
  registrar("v1", 1, "Login correcto", "POST", "/api/auth/login", 200, r, { cuerpo: ADMIN });
  const malo = { ...ADMIN, password: "incorrecta" };
  r = await pedir(B, "POST", "/api/auth/login", { body: malo });
  registrar("v1", 2, "Login incorrecto", "POST", "/api/auth/login", 401, r, { cuerpo: malo });
  r = await pedir(B, "GET", "/api/auth/perfil");
  registrar("v1", 3, "Perfil sin token", "GET", "/api/auth/perfil", 401, r);
  r = await pedir(B, "GET", "/api/auth/perfil", { token });
  registrar("v1", 4, "Perfil con token válido", "GET", "/api/auth/perfil", 200, r);
  r = await pedir(B, "GET", "/api/auth/perfil", { token: manipular(token) });
  registrar("v1", 5, "Perfil con token manipulado", "GET", "/api/auth/perfil", 401, r);
  resultados.v1_consola = s.salida();
  s.proc.kill();
}

// ================= V2 =================
{
  const s = await levantar("lab-paseto-v2", 3102);
  const B = "http://localhost:3102";
  let r = await pedir(B, "POST", "/api/auth/login", { body: ADMIN });
  const tA = r.body.token;
  registrar("v2", 1, "Login correcto (administrador)", "POST", "/api/auth/login", 200, r, { cuerpo: ADMIN });
  r = await pedir(B, "GET", "/api/auth/perfil", { token: tA });
  registrar("v2", 2, "Perfil con PASETO (administrador)", "GET", "/api/auth/perfil", 200, r);
  r = await pedir(B, "GET", "/api/auth/perfil");
  registrar("v2", 3, "Perfil sin PASETO", "GET", "/api/auth/perfil", 401, r);
  r = await pedir(B, "GET", "/api/usuarios", { token: tA });
  registrar("v2", 4, "Listar usuarios (administrador)", "GET", "/api/usuarios", 200, r);
  const tL = (await pedir(B, "POST", "/api/auth/login", { body: LAURA })).body.token;
  r = await pedir(B, "GET", "/api/usuarios/1", { token: tL });
  registrar("v2", 5, "Consultar usuario por ID (médico)", "GET", "/api/usuarios/1", 200, r);
  r = await pedir(B, "GET", "/api/usuarios", { token: tL });
  registrar("v2", 6, "Listar usuarios (médico)", "GET", "/api/usuarios", 403, r);
  const tC = (await pedir(B, "POST", "/api/auth/login", { body: CARLOS })).body.token;
  r = await pedir(B, "GET", "/api/auth/perfil", { token: tC });
  registrar("v2", 7, "Perfil (paciente)", "GET", "/api/auth/perfil", 200, r);
  r = await pedir(B, "GET", "/api/usuarios", { token: tC });
  registrar("v2", 8, "Listar usuarios (paciente)", "GET", "/api/usuarios", 403, r);
  const malo = { ...ADMIN, password: "incorrecta" };
  r = await pedir(B, "POST", "/api/auth/login", { body: malo });
  registrar("v2", 9, "Password incorrecto", "POST", "/api/auth/login", 401, r, { cuerpo: malo });
  const nadie = { email: "noexiste@hospital.com", password: "123456" };
  r = await pedir(B, "POST", "/api/auth/login", { body: nadie });
  registrar("v2", 10, "Usuario inexistente", "POST", "/api/auth/login", 401, r, { cuerpo: nadie });
  r = await pedir(B, "GET", "/api/auth/perfil", { token: manipular(tA) });
  registrar("v2", 11, "PASETO manipulado", "GET", "/api/auth/perfil", 401, r);
  r = await pedir(B, "GET", "/api/usuarios/999", { token: tA });
  registrar("v2", 12, "Usuario inexistente por ID (administrador)", "GET", "/api/usuarios/999", 404, r);
  const sw = await fetch(B + "/api-docs/");
  resultados.v2_swagger = sw.status;
  s.proc.kill();
}

// ================= V3 =================
{
  const s = await levantar("lab-paseto-v3", 3103);
  const B = "http://localhost:3103";
  const U = "/api/usuarios";
  let r = await pedir(B, "POST", "/api/auth/login", { body: ADMIN });
  const tA = r.body.token;
  registrar("v3", 1, "Login administrador", "POST", "/api/auth/login", 200, r, { cuerpo: ADMIN });
  r = await pedir(B, "GET", "/api/auth/perfil", { token: tA });
  registrar("v3", 2, "Perfil con token válido", "GET", "/api/auth/perfil", 200, r);
  r = await pedir(B, "GET", U, { token: tA });
  registrar("v3", 3, "Listar usuarios como admin", "GET", U, 200, r);
  const ana = { nombre: "Ana Torres", email: "ana@hospital.com", password: "123456", rol: "paciente", activo: true };
  r = await pedir(B, "POST", U, { token: tA, body: ana });
  registrar("v3", 4, "Crear usuario", "POST", U, 201, r, { cuerpo: ana });
  r = await pedir(B, "GET", U + "/4", { token: tA });
  registrar("v3", 5, "Consultar usuario creado", "GET", U + "/4", 200, r);
  const ana2 = { nombre: "Ana Torres Actualizada", email: "ana@hospital.com", password: "654321", rol: "medico", activo: true };
  r = await pedir(B, "PUT", U + "/4", { token: tA, body: ana2 });
  registrar("v3", 6, "PUT completo", "PUT", U + "/4", 200, r, { cuerpo: ana2 });
  let c = { nombre: "Ana Torres" };
  r = await pedir(B, "PUT", U + "/4", { token: tA, body: c });
  registrar("v3", 7, "PUT incompleto", "PUT", U + "/4", 400, r, { cuerpo: c });
  c = { activo: false };
  r = await pedir(B, "PATCH", U + "/4", { token: tA, body: c });
  registrar("v3", 8, "PATCH parcial", "PATCH", U + "/4", 200, r, { cuerpo: c });
  r = await pedir(B, "PATCH", U + "/4", { token: tA, body: {} });
  registrar("v3", 9, "PATCH vacío", "PATCH", U + "/4", 400, r, { cuerpo: {} });
  c = { nombre: "Pedro Ruiz", email: "esto-no-es-un-email", password: "123456", rol: "paciente", activo: true };
  r = await pedir(B, "POST", U, { token: tA, body: c });
  registrar("v3", 10, "Email inválido", "POST", U, 400, r, { cuerpo: c });
  c = { nombre: "Pedro Ruiz", email: "pedro@hospital.com", password: "123456", rol: "superadministrador", activo: true };
  r = await pedir(B, "POST", U, { token: tA, body: c });
  registrar("v3", 11, "Rol inválido", "POST", U, 400, r, { cuerpo: c });
  c = { nombre: "Otro administrador", email: "admin@hospital.com", password: "123456", rol: "paciente", activo: true };
  r = await pedir(B, "POST", U, { token: tA, body: c });
  registrar("v3", 12, "Email duplicado", "POST", U, 409, r, { cuerpo: c });
  r = await pedir(B, "GET", U + "/999", { token: tA });
  registrar("v3", 13, "Usuario inexistente", "GET", U + "/999", 404, r);
  r = await pedir(B, "DELETE", U + "/4", { token: tA });
  registrar("v3", 14, "DELETE", "DELETE", U + "/4", 204, r);
  r = await pedir(B, "GET", U + "/4", { token: tA });
  registrar("v3", 15, "GET después de DELETE", "GET", U + "/4", 404, r);
  r = await pedir(B, "GET", U);
  registrar("v3", 16, "Endpoint protegido sin PASETO", "GET", U, 401, r);
  r = await pedir(B, "GET", U, { token: manipular(tA) });
  registrar("v3", 17, "PASETO modificado", "GET", U, 401, r);
  const tL = (await pedir(B, "POST", "/api/auth/login", { body: LAURA })).body.token;
  r = await pedir(B, "GET", U + "/1", { token: tL });
  registrar("v3", 18, "Médico consulta usuario por ID", "GET", U + "/1", 200, r);
  r = await pedir(B, "GET", U, { token: tL });
  registrar("v3", 19, "Médico lista todos los usuarios", "GET", U, 403, r);
  r = await pedir(B, "POST", U, { token: tL, body: ana });
  registrar("v3", 20, "Médico intenta crear usuario", "POST", U, 403, r, { cuerpo: ana });
  const tC = (await pedir(B, "POST", "/api/auth/login", { body: CARLOS })).body.token;
  r = await pedir(B, "GET", U, { token: tC });
  registrar("v3", 21, "Paciente intenta acceder a usuarios", "GET", U, 403, r);
  const r21b = await pedir(B, "GET", U + "/1", { token: tC });
  const r21c = await pedir(B, "GET", "/api/auth/perfil", { token: tC });
  resultados.v3_paciente = { usuarios1: r21b.status, perfil: r21c.status };
  c = { ...ADMIN, password: "incorrecta" };
  r = await pedir(B, "POST", "/api/auth/login", { body: c });
  registrar("v3", 22, "Password incorrecto", "POST", "/api/auth/login", 401, r, { cuerpo: c });
  c = { email: "noexiste@hospital.com", password: "123456" };
  r = await pedir(B, "POST", "/api/auth/login", { body: c });
  registrar("v3", 23, "Email inexistente", "POST", "/api/auth/login", 401, r, { cuerpo: c });

  // Matriz de permisos (PUT/PATCH/DELETE por rol sobre un id inexistente no altera datos)
  const m = {};
  for (const [rol, t] of [["administrador", tA], ["medico", tL], ["paciente", tC]]) {
    m[rol] = {
      put: (await pedir(B, "PUT", U + "/999", { token: t, body: ana2 })).status,
      patch: (await pedir(B, "PATCH", U + "/999", { token: t, body: { activo: false } })).status,
      delete: (await pedir(B, "DELETE", U + "/999", { token: t })).status,
    };
  }
  resultados.v3_matriz = m;
  resultados.v3_swagger = (await fetch(B + "/api-docs/")).status;
  s.proc.kill();
}

writeFileSync("pruebas/resultados.json", JSON.stringify(resultados, null, 2));
let total = 0, ok = 0;
for (const v of ["v1", "v2", "v3"]) {
  console.log(`\n===== ${v.toUpperCase()} =====`);
  for (const p of resultados[v]) {
    total++; if (p.ok) ok++;
    console.log(`${p.ok ? "OK  " : "FAIL"} #${String(p.n).padStart(2)} ${p.metodo.padEnd(6)} ${p.ruta.padEnd(20)} esperado ${p.esperado} obtenido ${p.obtenido}  ${p.nombre}`);
  }
}
console.log(`\nTOTAL: ${ok}/${total} pruebas correctas`);
process.exit(ok === total ? 0 : 1);
