# Laboratorio PASETO V1 · V2 · V3

API REST con Node.js + Express y autenticación PASETO v4.public, en tres versiones incrementales.

| Carpeta | Versión | Contenido |
| --- | --- | --- |
| `lab-paseto` | V1 | Login, generación y verificación del PASETO, ruta protegida |
| `lab-paseto-v2` | V2 | Usuarios locales, roles, autorización, Swagger |
| `lab-paseto-v3` | V3 | CRUD completo, validaciones (express-validator), roles, Swagger |

## Ejecutar una versión

```bash
cd lab-paseto-v3
npm install
npm run dev
```

Swagger (V2 y V3): http://localhost:3000/api-docs

## Ejecutar las pruebas automáticas (40 casos)

Con las dependencias de las tres carpetas instaladas, desde la raíz:

```bash
node pruebas/ejecutar-pruebas.mjs
```

El script levanta cada API en un puerto propio (3101–3103), ejecuta las pruebas de las guías
(5 de V1, 12 de V2, 23 de V3) y guarda el detalle en `pruebas/resultados.json`.

## Usuarios de prueba

| Email | Password | Rol |
| --- | --- | --- |
| admin@hospital.com | 123456 | administrador |
| laura@hospital.com | 123456 | medico |
| carlos@hospital.com | 123456 | paciente |

> Proyecto educativo: contraseñas en texto plano, datos en memoria y claves generadas al iniciar el servidor.
